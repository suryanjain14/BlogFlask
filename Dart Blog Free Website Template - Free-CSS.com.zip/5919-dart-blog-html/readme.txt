
### Fonts

# Geometria
# Material iconic font

Images & icons
# https://www.pexels.com



License 

* You have the rights to use the templates for personal and commercial project(s).
* You are allowed to make necessary modification(s) to our templates to fit your purpose.
* Modification of the template or part it does not grant ownership of the template.
* You cannot resell, redistribute, or sub-license any of Themefisher�s templates.
* You can host themefisher�s template to your website with full author credit
* You are most welcome to share our templates with your clients/friends, but please share our licence with them so that they can be aware of our copyrights.
* You can convert our templates on any CMS (like WordPress, Joomla etc.) for your client and personal purposes but cannot resell these templates after the CMS conversion. 

This PSD template copyright by DartThemes.com