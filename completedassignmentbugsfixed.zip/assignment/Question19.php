<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title></title>
</head>
<body>
Student List is :</br>
<?php
$dbhost = '10.81.203.8:8558';
$dbuser = 'IIPS';
$dbpass = 'IIPSPwd';
$dbname = 'test';
$tableName = "StudentDB";
$conn = mysql_connect($dbhost, $dbuser, $dbpass);
if (!$conn)
    die('Could not connect: ' . mysql_error());
if (!mysql_select_db($dbname))
    die("Can't select database");
$result = mysql_query("SELECT * FROM {$tableName}");
if (!$result)
    die("Query to show fields from table failed!" . mysql_error());

$fields_num = mysql_num_fields($result);
echo "<h1>Table: {$tableName}</h1>";
echo "<table border='1'><tr>";
for ($i = 0; $i < $fields_num; $i++) {
    $field = mysql_fetch_field($result);
    echo "<td><b>{$field->name}</b></td>";
}
echo "</tr>\n";

while ($row = mysql_fetch_array($result)) {
    echo "<tr>";

    echo "<td>" . $row['stuid'] . "</td>";
    echo "<td>" . $row['stuname'] . "</td>";
    echo "<td>" . $row['cgpa'] . "</td>";
    echo "</tr>\n";
}
mysql_free_result($result);
mysql_close($conn);
?>
</body>
</html>