<!DOCTYPE html>
<html lang="en">

<?php
$name = $_GET["name"];
$id = $_GET["id"];
$cgpa = $_GET["cgpa"];
$dbhost = '10.81.203.8:8558';
$dbuser = 'IIPS';
$dbpass = 'IIPSPwd';
$dbname = 'StudentDB';
$tableName = "StuMast";
$conn = mysqli($dbhost, $dbuser, $dbpass, $dbname);
if ($conn->connect_error)
    die('Could not connect: ' . $conn->connect_error());

$sql = "INSERT INTO {$tableName} (Stu_ID, Stu_Name, cgpa)
VALUES ('{$id}', '[$name]', '{$cgpa}')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

</html>